$exe = Join-Path $PSScriptRoot "CHATBOT.exe"

while ($true) {
    $p = Start-Process -FilePath $exe -WorkingDirectory $PSScriptRoot -PassThru
    $p.WaitForExit()
    Start-Sleep -Seconds 2
}