=== How to Run ===
1. Right-click the zip and select 'Extract All...' to a folder on your computer.
   IMPORTANT: Do NOT run hope.exe directly from inside the zip archive! All DLLs must stay in the same folder as hope.exe.

2. Run hope.exe.
   - When the Windows UAC (User Account Control) prompt appears, click 'Yes'.
   - Administrator elevation ensures global hotkeys (Alt+/, Alt+T, etc.) work everywhere across ALL apps (Task Manager, elevated browsers, games, etc.).

3. If Windows SmartScreen shows a blue popup ('Windows protected your PC'):
   - Click 'More info'
   - Click 'Run anyway'

4. All required runtime DLLs (Visual C++ runtime, WebView2Loader, Dll1) are already included in this folder.
