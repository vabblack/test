Mile Assistant
================

How to Run:
1. Extract all files from this zip into a folder.
2. Double-click 'mile.exe' to run the application.

Note on Windows SmartScreen:
Because this application is freshly compiled and does not carry a commercial code-signing certificate, Windows Defender or SmartScreen will prompt:
'Windows protected your PC - Windows SmartScreen prevented an unrecognized app from starting.'

To run:
1. Click 'More info'.
2. Click 'Run anyway'.

Memory & Local Storage:
- All screenshots are captured and processed 100% in RAM (never written to disk).
- Debug file logging has been completely disabled.
- Only your custom keybindings ('hotkeys.json') and API keys are stored locally.
AQ.Ab8RN6JqELxKbQPOtWRoCaEjT0wI4q6Rd79LcvmmNykxOPxesw
g
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