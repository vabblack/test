=== Hope Assistant ===

--- Quick Start ---
1. Extract ALL files from this zip into a folder on your computer.
   IMPORTANT: Do NOT run hope.exe directly from inside the zip! All accompanying DLL files must remain in the same folder as hope.exe.
2. Launch hope.exe (Run as Administrator is recommended for full global hotkey capture and stealth overlay features).
3. If Windows SmartScreen appears ('Windows protected your PC'):
   - Click 'More info'
   - Click 'Run anyway'

--- Default Hotkeys ---
* Show / Hide Overlay:      Alt + /
* Send / Process Prompt:    Ctrl + Enter
* Screenshot Capture:       Alt + \
* Smart Snip Mode:          Alt + S
* AutoType Response:        Alt + T
* Quit Application:         Alt + Backspace

--- Included Files ---
* hope.exe           - Main executable
* Dll1.dll           - Stealth injection & hook library
* WebView2Loader.dll - Embedded browser runtime loader
* hotkeys.json       - Shortcut & application configuration
* msvcp140.dll       - Visual C++ Runtime
* vcruntime140.dll   - Visual C++ Runtime
* vcruntime140_1.dll - Visual C++ Runtime
